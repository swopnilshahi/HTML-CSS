Problem faced during  project
    --fontawesome icon were not showing --
    download the package and applied on the projecrt
    free domin
     https://www.freenom.com/en/index.html?lang=en